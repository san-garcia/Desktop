import { Component } from '@angular/core';

@Component({
  selector: 'app-camisetas',
  standalone: true,
  imports: [],
  templateUrl: './camisetas.component.html',
  styleUrl: './camisetas.component.css'
})
export class CamisetasComponent {

}
