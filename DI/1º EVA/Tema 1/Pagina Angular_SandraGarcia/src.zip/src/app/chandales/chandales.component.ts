import { Component } from '@angular/core';

@Component({
  selector: 'app-chandales',
  standalone: true,
  imports: [],
  templateUrl: './chandales.component.html',
  styleUrl: './chandales.component.css'
})
export class ChandalesComponent {

}
