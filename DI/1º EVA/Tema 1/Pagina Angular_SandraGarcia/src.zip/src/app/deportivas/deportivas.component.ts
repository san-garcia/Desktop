import { Component } from '@angular/core';

@Component({
  selector: 'app-deportivas',
  standalone: true,
  imports: [],
  templateUrl: './deportivas.component.html',
  styleUrl: './deportivas.component.css'
})
export class DeportivasComponent {

}
