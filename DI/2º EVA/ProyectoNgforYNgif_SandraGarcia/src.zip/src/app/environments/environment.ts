export const environment = {
    production: false,
    firebase: {
        apiKey: "AIzaSyDVGLXk9ocMjC14Cw6I3GW1EQ7JKnZPOtk",
        authDomain: "proyectosandra-b2ec3.firebaseapp.com",
        databaseURL: "https://proyectosandra-b2ec3-default-rtdb.europe-west1.firebasedatabase.app",
        projectId: "proyectosandra-b2ec3",
        storageBucket: "proyectosandra-b2ec3.firebasestorage.app",
        messagingSenderId: "228818182607",
        appId: "1:228818182607:web:b43b06fb7d01860a3fb2ba",
        measurementId: "G-69040SR4L4"
    }
};