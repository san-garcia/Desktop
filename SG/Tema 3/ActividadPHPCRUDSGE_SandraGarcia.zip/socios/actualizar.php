<?php
if (isset($_POST['actualizar'])) {
    // Me conecto a la bbdd 
    $pdo = new PDO('mysql:host=localhost;dbname=videoclub', 'root', '');

    // Compruebo que se ha conectado sin problemas 
    echo "<script>alert('Conexión establecida con éxito');</script>";

    // Creo la sentencia
    $sentencia = $pdo->prepare("update socios set nombre=:nombre, apellidos=:apellidos, direccion=:direccion, 
    telefono=:telefono, poblacion=:poblacion where codsocio=:codsocio");

    // Obtengo el código que ha introducido el usuario
    $codsocio = $_POST['codsocio'];
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $direccion = $_POST['direccion'];
    $telefono = $_POST['telefono'];
    $poblacion = $_POST['poblacion'];

    // Le asigno al parámetro las variables que he creado 
    $sentencia->bindParam(':codsocio', $codsocio);
    $sentencia->bindParam(':nombre', $nombre);
    $sentencia->bindParam(':apellidos', $apellidos);
    $sentencia->bindParam(':direccion', $direccion);
    $sentencia->bindParam(':telefono', $telefono);
    $sentencia->bindParam(':poblacion', $poblacion);

    // Ejecuto la sentencia 
    if ($sentencia->execute()) {
        echo "<script>alert('Datos insertados correctamente');</script>";
        header("Location: listado.php");
    } else {
        echo "<script>alert('Error al insertar los datos');</script>";
        header("Location: listado.php");
    }
} else {
    echo "<script>alert('Conexión no establecida');</script>";
    header("Location: listado.php");
}
