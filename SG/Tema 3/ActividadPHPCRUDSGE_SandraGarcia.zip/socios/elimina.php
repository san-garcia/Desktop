<?php
if (isset($_POST['elimina'])) {
    // Me conecto a la bbdd 
    $pdo = new PDO('mysql:host=localhost;dbname=videoclub', 'root', '');

    // Compruebo que se ha conectado sin problemas 
    echo "<script>alert('Conexión establecida con éxito');</script>";

    // Obtengo el cógo que ha introducido el usuario
    $codsocio = $_POST['codsocio'];

    // Creo la sentencia de consultar, que sera por codsocio 
    $sentencia = $pdo->prepare("delete from socios where codsocio=:codsocio");

    // Le asigno al parámetro la variable que he creado $codsocio 
    $sentencia->bindParam(':codsocio', $codsocio);

    // Ejecuto la sentencia 
    $sentencia->execute();

    // Muestro que se ha eliminado correctamente
    if ($sentencia->rowCount() > 0) {
        // Creo la sentencia de consultar, que sera por codsocio 
        $sentencia = $pdo->prepare("delete from socios where codsocio=:codsocio");

        // Le asigno al parámetro la variable que he creado $codsocio 
        $sentencia->bindParam(':codsocio', $codsocio);

        // Ejecuto la sentencia 
        $sentencia->execute();

        // Muestro que se ha eliminado
        echo "<script>alert('Socio eliminado correctamente');</script>";
        header("Location: listado.php");
    } else {
        echo "<script>alert('No se ha podido eliminar');</script>";
        header("Location: listado.php");
    }
} else {
    echo "<script>alert('Conexión no establecida');</script>";
    header("Location: listado.php");
}
