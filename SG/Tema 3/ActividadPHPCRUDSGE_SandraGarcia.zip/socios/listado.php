<?php
    // Me conecto a la bbdd 
    $pdo = new PDO('mysql:host=localhost;dbname=videoclub', 'root', '');

    // Compruebo que se ha conectado sin problemas 
    echo "<script>alert('Conexión establecida con éxito');</script>";
    
    // Creo la sentencia para listar todos los socios 
    $sentencia = $pdo->query("select * from socios");

    // Ejecuto la sentencia 
    $sentencia->execute();

    // Recupero todos los registros mediante un array multidimensional 
    $registros = $sentencia->fetchAll(PDO::FETCH_ASSOC);

?>
<!--Contenido HTML y CSS-->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Socios</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        table {
            width: 80%;
            margin: 0 auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>

<body>
    <h1>Listado de Socios</h1>
    <table>
        <tr>
            <th>Código</th>
            <th>Nombre</th>
            <th>Apellidos</th>
            <th>Dirección</th>
            <th>Teléfono</th>
            <th>Población</th>
        </tr>
        <?php foreach ($registros as $socio): ?>
            <tr>
                <td><?php echo htmlspecialchars($socio['codsocio']); ?></td>
                <td><?php echo htmlspecialchars($socio['nombre']); ?></td>
                <td><?php echo htmlspecialchars($socio['apellidos']); ?></td>
                <td><?php echo htmlspecialchars($socio['direccion']); ?></td>
                <td><?php echo htmlspecialchars($socio['telefono']); ?></td>
                <td><?php echo htmlspecialchars($socio['poblacion']); ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>

</html>