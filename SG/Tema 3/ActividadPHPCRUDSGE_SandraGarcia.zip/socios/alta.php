<?php
if (isset($_POST['alta'])) {
    // Me conecto a la bbdd 
    $pdo = new PDO('mysql:host=localhost;dbname=videoclub', 'root', '');

    // Compruebo que se ha conectado sin problemas 
    echo "<script>alert('Conexión establecida con éxito');</script>";

    // Obtengo el código que ha introducido el usuario
    $codsocio = $_POST['codsocio'];
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $direccion = $_POST['direccion'];
    $telefono = $_POST['telefono'];
    $poblacion = $_POST['poblacion'];

    // Creo la sentencia
    $sentencia = $pdo->prepare("INSERT INTO socios (codsocio, nombre, apellidos, direccion, telefono, poblacion) VALUES (:codsocio, :nombre, :apellidos, :direccion, :telefono, :poblacion)");

    // Le asigno al parámetro las variables que he creado 
    $sentencia->bindParam(':codsocio', $codsocio);
    $sentencia->bindParam(':nombre', $nombre);
    $sentencia->bindParam(':apellidos', $apellidos);
    $sentencia->bindParam(':direccion', $direccion);
    $sentencia->bindParam(':telefono', $telefono);
    $sentencia->bindParam(':poblacion', $poblacion);

    // Ejecuto la sentencia 
    if ($sentencia->execute()) {
        echo "<script>alert('Datos insertados correctamente');</script>";
        header("Location: listado.php");
    } else {
        echo "<script>alert('Error al insertar los datos');</script>";
        header("Location: listado.php");
    }
} else {
    echo "<script>alert('Conexión no establecida');</script>";
    header("Location: listado.php");
}
