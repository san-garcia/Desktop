<!--Contenido HTML y CSS-->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario Alta Socio</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .formulario {
            width: 100%;
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            font-size: 16px;
            color: #555;
            margin-bottom: 8px;
            display: block;
        }

        input[type="text"], input[type="number"], input[type="tel"], textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <h2>Formulario de Alta Socio</h2>
    <div class="formulario">
        <form method="post" action="alta.php">
            <label for="codsocio">Código de Socio</label>
            <input type="number" name="codsocio" required>

            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" required>

            <label for="apellidos">Apellidos</label>
            <input type="text" name="apellidos" required>

            <label for="direccion">Dirección</label>
            <textarea name="direccion" required></textarea>

            <label for="telefono">Teléfono</label>
            <input type="text" name="telefono" required>

            <label for="poblacion">Población</label>
            <input type="text" name="poblacion" required>

            <input type="submit" name="alta" value="Dar Alta Socio">
        </form>
    </div>

</body>

</html>