<!--Contenido HTML y CSS-->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Buscar Socio</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .button-container, .formulario {
            text-align: center;
            margin-top: 20px;
        }

        button, input[type="text"] {
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <h2>Consultar Socio para Actualizar</h2>
    <div class="formulario">
    <form method="post" action="formActualizar.php">
        <input type="text" name="codsocio" placeholder="Ingrese el código de socio" required>
        <button type="submit" name="elimina">Buscar Socio</button>
    </form>
    </div>
</body>

</html>