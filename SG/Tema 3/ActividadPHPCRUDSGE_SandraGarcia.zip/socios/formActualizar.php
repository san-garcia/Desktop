<?php
if (isset($_POST['codsocio'])) {
    $pdo = new PDO('mysql:host=localhost;dbname=videoclub', 'root', '');

    $codsocio = $_POST['codsocio'];

    // Consulta para obtener los datos del socio
    $sentencia = $pdo->prepare("SELECT * FROM socios WHERE codsocio = :codsocio");
    $sentencia->bindParam(':codsocio', $codsocio);
    $sentencia->execute();

    $socio = $sentencia->fetch(PDO::FETCH_ASSOC);

    if ($socio) {
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Actualizar Socio</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f9;
        margin: 0;
        padding: 0;
    }

    .formulario {
        width: 100%;
        max-width: 500px;
        margin: 50px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            font-size: 16px;
            color: #555;
            margin-bottom: 8px;
            display: block;
        }

        input[type="text"], input[type="number"], input[type="tel"], textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
        </head>
        <body>
            <h2>Actualizar Datos del Socio</h2>
            <div class="formulario">
            <form method="post" action="actualizar.php">
                <input type="hidden" name="codsocio" value="<?php echo $socio['codsocio']; ?>">

                <label for="nombre">Nombre:</label>
                <input type="text" name="nombre" value="<?php echo $socio['nombre']; ?>" required><br>

                <label for="apellidos">Apellidos:</label>
                <input type="text" name="apellidos" value="<?php echo $socio['apellidos']; ?>" required><br>

                <label for="direccion">Dirección:</label>
                <input type="text" name="direccion" value="<?php echo $socio['direccion']; ?>" required><br>

                <label for="telefono">Teléfono:</label>
                <input type="tel" name="telefono" value="<?php echo $socio['telefono']; ?>" required><br>

                <label for="poblacion">Población:</label>
                <input type="text" name="poblacion" value="<?php echo $socio['poblacion']; ?>" required><br>

                <input type="submit" name="actualizar" value="Actualizar">
            </form>
            </div>
        </body>

        </html>
<?php
    } else {
        echo "<script>alert('No se encontró el socio'); window.location.href='formConsActualizar.php';</script>";
    }
} else {
    header("Location: formConsActualizar.php");
}
?>