<?php
if (isset($_POST['consulta'])) {
    // Me conecto a la bbdd 
    $pdo = new PDO('mysql:host=localhost;dbname=videoclub', 'root', '');

    // Compruebo que se ha conectado sin problemas 
    echo "<script>alert('Conexión establecida con éxito');</script>";

    // Creo la sentencia de consultar, que sera por codsocio 
    $sentencia = $pdo->prepare("select * from socios where codsocio=:codsocio");

    // Le doy el parámetro :codsocio 
    $codsocio = $_POST['codsocio'];

    // Le asigno al parámetro la variable que he creado $codsocio 
    $sentencia->bindParam(':codsocio', $codsocio);

    // Ejecuto la sentencia 
    $sentencia->execute();

    // Recupero todos los registros con el método fetchAll
    $registros = $sentencia->fetchAll(PDO::FETCH_ASSOC);

    // Muestro los datos 
    echo "<h2>Resultado de la búsqueda:</h2>";
    echo "<table border='1'>
                    <tr>
                        <th>Código</th>
                        <th>Nombre</th>
                        <th>Apellidos</th>
                        <th>Dirección</th>
                        <th>Teléfono</th>
                        <th>Población</th>
                    </tr>";
    foreach ($registros as $socio) {
        echo "<tr>
                        <td>{$socio['codsocio']}</td>
                        <td>{$socio['nombre']}</td>
                        <td>{$socio['apellidos']}</td>
                        <td>{$socio['direccion']}</td>
                        <td>{$socio['telefono']}</td>
                        <td>{$socio['poblacion']}</td>
                      </tr>";
    }
} else {
    echo "<script>alert('Conexión no establecida');</script>";
    header("Location: listado.php");
}
?>
<!--Estilo CSS-->
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 20px;
    }

    h2 {
        text-align: center;
        color: #333;
    }

    table {
        width: 80%;
        margin: 20px auto;
        border-collapse: collapse;
        background-color: #fff;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    th,td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    th {
        background-color: #4CAF50;
        color: white;
    }

    tr:hover {
        background-color: #f1f1f1;
    }

    .button-container, .search-container {
        text-align: center;
        margin-top: 20px;
    }

    button, input[type="text"] {
        padding: 10px 20px;
        font-size: 16px;
        border-radius: 4px;
        border: 1px solid #ccc;
    }

    button {
        background-color: #4CAF50;
        color: white;
        border: none;
        cursor: pointer;
    }

    button:hover {
        background-color: #45a049;
    }
</style>