<?php
$alumnos = [
    "Luis" => 4.5,
    "Pedro" => 7.3,
    "Ana" => 8.5,
    "Rosa" => 3.1,
    "Ángel" => 1.5,
    "María" => 6.5,
    "Sara" => 9.1,
    "Roberto" => 3.5
];
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        table {
            width: 50%;
            margin: 20px auto;
            border-collapse: collapse;
            font-family: Arial, sans-serif;
            font-weight: bold;
        }

        th,
        td {
            border: 2px solid #7ba0cd;
            padding: 10px;
            text-align: left;
            background-color: #d3dfee;
            color: #365f91;
        }

        th {
            background-color: #4f81bd;
            color: white;
        }
    </style>
</head>

<body>
    <table>
        <thead>
            <tr>
                <th>Índice</th>
                <th>Valor</th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($alumnos as $nombre => $nota) {
                echo "<tr><td>$nombre</td><td>$nota</td></tr>";
            }
            /*Ejercicio 7. Buscar si existe el alumno Rosa y el alumno Manuel.*/
            echo "<h2>Ejercicio 7. Buscar si existe el alumno Rosa y el alumno Manuel.</h2>";
            echo "Rosa " . (array_key_exists("Rosa", $alumnos) ? "existe" : "no existe") . "<br>";
            echo "Manuel " . (array_key_exists("Manuel", $alumnos) ? "existe" : "no existe") . "<br>";

            /*Ejercicio 8. Añadir el siguiente alumno y mostrar el listado:*/
            echo "<h2>Ejercicio 8. Añadir el siguiente alumno y mostrar el listado:</h2>";
            $alumnos["Alba"] = 9.5;
            foreach ($alumnos as $nombre => $nota) {
                echo "$nombre: $nota<br>";
            }

            /*Ejercicio 9. Ordenar el array por las notas de menor a mayor y mostrar el listado. */
            echo "<h2>Ejercicio 9. Ordenar el array por las notas de menor a mayor y mostrar el listado.</h2>";
            asort($alumnos);
            foreach ($alumnos as $nombre => $nota) {
                echo "$nombre: $nota<br>";
            }

            /*Ejercicio 10. Ordenar el array por las el nombre del alumno de menor a mayor y mostrar el listado.*/
            echo "<h2>Ejercicio 10. Ordenar el array por las el nombre del alumno de menor a mayor y mostrar el listado.</h2>";
            ksort($alumnos);
            foreach ($alumnos as $nombre => $nota) {
                echo "$nombre: $nota<br>";
            }

            /*Ejercicio 11. Ordenar el array por las notas de mayor a menor y mostrar el listado.*/
            echo "<h2>Ejercicio 11. Ordenar el array por las notas de mayor a menor y mostrar el listado.</h2>";
            arsort($alumnos);
            foreach ($alumnos as $nombre => $nota) {
                echo "$nombre: $nota<br>";
            }

            /*Ejercicio 12. Ordenar el array por las el nombre del alumno de mayor a menor y mostrar el listado.*/
            echo "<h2>Ejercicio 12. Ordenar el array por las el nombre del alumno de mayor a menor y mostrar el listado.</h2>";
            krsort($alumnos);
            foreach ($alumnos as $nombre => $nota) {
                echo "$nombre: $nota<br>";
            }

            /*Ejercicio 13. Crear un array asociativo cuya clave es el nombre del empleado y el valor asociado el sueldo del empleado y mostrar el listado.*/
            $empleados = $alumnos;
            echo "<h2>Ejercicio 13. Crear un array asociativo cuya clave es el nombre del empleado y el valor asociado el sueldo del empleado y mostrar el listado.</h2>";
            foreach ($empleados as $empleado => $sueldo) {
                echo "$empleado: $sueldo<br>";
            }

            /*Ejercicio 14. Desplazarnos tres posiciones en el array de empleados y devolver el nombre y la nota del empleado actual.*/
            echo "<h2>Ejercicio 14. Desplazarnos tres posiciones en el array de empleados y devolver el nombre y la nota del empleado actual.</h2>";
            reset($empleados);
            next($empleados);
            next($empleados);
            next($empleados);
            echo "Empleado actual: " . key($empleados) . " - Sueldo: " . current($empleados) . "<br>";

            /*Ejercicio 15. Retroceder una posición en el array de empleados y devolver el nombre y la nota del empleado actual*/
            echo "<h2>Ejercicio 15. Retroceder una posición en el array de empleados y devolver el nombre y la nota del empleado actual</h2>";
            prev($empleados);
            echo "Empleado actual: " . key($empleados) . " - Sueldo: " . current($empleados) . "<br>";
            
            /*Ejercicio 16. Ir a la primera posición del array de empleados y devolver el nombre y la nota del empleado actual.*/
            echo "<h2>Ejercicio 16. Ir a la primera posición del array de empleados y devolver el nombre y la nota del empleado actual.</h2>";
            reset($empleados);
            echo "Empleado actual: " . key($empleados) . " - Sueldo: " . current($empleados) . "<br>";

            /*Ejercicio 17. Ir a la última posición del array de empleados y devolver el nombre y la nota del empleado actual*/
            echo "<h2>Ejercicio 17. Ir a la última posición del array de empleados y devolver el nombre y la nota del empleado actual.</h2>";
            end($empleados);
            echo "Empleado actual: " . key($empleados) . " - Sueldo: " . current($empleados) . "<br>";

            /*Ejercicio 18. Mostrar el número de empleados del array.*/
            echo "<h2>Ejercicio 18. Mostrar el número de empleados del array.</h2>";
            echo "Número de empleados: " . count($empleados) . "<br>";
            ?>

        </tbody>
    </table>
</body>

</html>