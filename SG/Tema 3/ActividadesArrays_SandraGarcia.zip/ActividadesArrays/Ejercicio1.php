<?php
$hoteles = [
    [
        "nombre" => "Abashiri (NH)",
        "cat" => "3*",
        "hab" => "168",
        "poblacion" => "46013 Valencia",
        "direccion" => "Avenida Ausias March, 59"
    ],
    [
        "nombre" => "Abba Acteon (Abba Hoteles)",
        "cat" => "4*",
        "hab" => "189",
        "poblacion" => "46023 Valencia",
        "direccion" => "Escultor Vicente Bertrán Grimal, 2"
    ],
    [
        "nombre" => "Acta Atarazanas",
        "cat" => "4*",
        "hab" => "42",
        "poblacion" => "46011 Valencia",
        "direccion" => "Plaza Tribunal de las Aguas, 4"
    ],
    [
        "nombre" => "Acta del Carmen",
        "cat" => "3*",
        "hab" => "25",
        "poblacion" => "46003 Valencia",
        "direccion" => "Blanquerías, 11"
    ],
    [
        "nombre" => "AC Valencia (AC Hotels)",
        "cat" => "4*",
        "hab" => "183",
        "poblacion" => "46023 Valencia",
        "direccion" => "Avenida de Francia, 67"
    ],
    [
        "nombre" => "Ad Hoc Monumental Valencia",
        "cat" => "3*",
        "hab" => "28",
        "poblacion" => "46003 Valencia",
        "direccion" => "Boix, 4"
    ],
    [
        "nombre" => "Alkazar",
        "cat" => "1*",
        "hab" => "18",
        "poblacion" => "46002 Valencia",
        "direccion" => "Mosén Femades, 11"
    ]
];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        table {
                width: 80%;
                margin: 20px auto;
                border-collapse: collapse;
                font-family: Arial, sans-serif;
            }
            th, td {
                border: 2px solid #7ba0cd;
                padding: 10px;
                text-align: left;
                background-color: #d3dfee;
                color: #365f91;
            }
            th {
                background-color: #4f81bd;
                color: white;
            }
    </style>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Categoría</th>
                <th>Habitaciones</th>
                <th>Población</th>
                <th>Dirección</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($hoteles as $hotel): ?>
                <!--Ejercicio 2. Mostrar el listado de hoteles.-->
                
                <!--Ejercicio 3. Mostrar los hoteles de más de 100 habitaciones.-->
                <!--if ($hotel['hab'] > 100)-->

                <!--Ejercicio 4. Mostrar los hoteles de menos de 100 habitaciones y 3 estrellas.-->
                <!--($hotel['hab'] < 100 && $hotel['cat'] = 3)-->

                <!--Ejercicio 5. Ordenar el listado de hoteles por el número de habitaciones y mostrar el listado.
                (array_multisort).-->
                
                <?php if ($hotel['hab'] < 100 && $hotel['cat'] = 3): ?> 
                    <tr>
                        <td><?= htmlspecialchars($hotel['nombre']); ?></td>
                        <td><?= htmlspecialchars($hotel['cat']); ?></td>
                        <td><?= htmlspecialchars($hotel['hab']); ?></td>
                        <td><?= htmlspecialchars($hotel['poblacion']); ?></td>
                        <td><?= htmlspecialchars($hotel['direccion']); ?></td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
