<?php
$poblaciones = [ 
    "Valencia", 
    "Castellón", 
    "Alicante", 
    "Murcia", 
    "Albacete", 
    "Teruel", 
    "Madrid", 
    "Barcelona"];

/*Ejercicio 19. Crear un array de poblaciones y mostrar el listado*/
echo "<h2>Ejercicio 19. Crear un array de poblaciones y mostrar el listado</h2>";
foreach ($poblaciones as $poblacion) {
    echo "$poblacion<br>";
}

/*Ejercicio 20. Insertar Ciudad Real al principio del array de poblaciones y mostrar el listado.*/ 
echo "<h2>Ejercicio 20. Insertar Ciudad Real al principio del array de poblaciones y mostrar el listado.</h2>";
array_unshift($poblaciones, "Ciudad Real");
foreach ($poblaciones as $poblacion) {
    echo "$poblacion<br>";
}

/*Ejercicio 21. Insertar Zaragoza al final del array de poblaciones y mostrar el listado.*/ 
echo "<h2>Ejercicio 21. Insertar Zaragoza al final del array de poblaciones y mostrar el listado.</h2>";
array_push($poblaciones, "Zaragoza");
foreach ($poblaciones as $poblacion) {
    echo "$poblacion<br>";
}

/*Ejercicio 22. Devolver un subarray con las poblaciones desde Teruel al final del array.*/ 
echo "<h2>Ejercicio 22. Devolver un subarray con las poblaciones desde Teruel al final del array.</h2>";
$subarray = array_slice($poblaciones, array_search("Teruel", $poblaciones));
foreach ($subarray as $poblacion) {
    echo "$poblacion<br>";
}

/*Ejercicio 23. Devolver un subarray con las 2 siguientes poblaciones a Valencia.*/ 
echo "<h2>Ejercicio 23. Devolver un subarray con las 2 siguientes poblaciones a Valencia.</h2>";
$indice = array_search("Valencia", $poblaciones);
$subarray = array_slice($poblaciones, $indice + 1, 2);
foreach ($subarray as $poblacion) {
    echo "$poblacion<br>";
}

/*Ejercicio 24. Mostrar el array de poblaciones en orden inverso.*/ 
echo "<h2>Ejercicio 24. Mostrar el array de poblaciones en orden inverso.</h2>";
$invertido = array_reverse($poblaciones);
foreach ($invertido as $poblacion) {
    echo "$poblacion<br>";
}

/*Ejercicio 25. Indicar se existe Alicante en el array de poblaciones.*/ 
echo "<h2>Ejercicio 25. Indicar se existe Alicante en el array de poblaciones.</h2>";
echo in_array("Alicante", $poblaciones) ? "Alicante existe<br>" : "Alicante no existe<br>";

/*Ejercicio 26. Indicar se existe Burgos en el array de poblaciones*/ 
echo "<h2>Ejercicio 26. Indicar se existe Burgos en el array de poblaciones</h2>";
echo in_array("Burgos", $poblaciones) ? "Burgos existe<br>" : "Burgos no existe<br>";
?> 
