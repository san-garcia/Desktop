<?php
$puestos = [
    "Administrativo", 
    "Informático", 
    "Comercial", 
    "Mozo Almacén", 
    "Comercial",
    "Informático", 
    "Administrativo", 
    "Administrativo", 
    "Gerente", 
    "Director",
    "Administrativo", 
    "Comercial", 
    "Mozo Almacén", 
    "Comercial", 
    "Informático",
    "Administrativo", 
    "Administrativo"
];
$conteo = array_count_values($puestos);
foreach ($conteo as $puesto => $cantidad) {
    echo "$puesto: $cantidad<br>";
}

/*Ejercicio 28. Combinar dos arrays de departamentos en un array de empleados y mostrar el resultado.*/
$administracion = ["Luis", "Ana", "Ángel", "María"];
$informatica = ["Pedro", "Rosa", "Roberto"];
echo "<h2>Ejercicio 28: Combinar arrays de departamentos</h2>";
$empleados = array_merge($administracion, $informatica);
foreach ($empleados as $empleado) {
    echo "$empleado<br>";
}
?>