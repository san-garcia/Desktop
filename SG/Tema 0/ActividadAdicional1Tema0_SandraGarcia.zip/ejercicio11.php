<?php
/*Ejercicio 11. Crear las variables codigo, nombre, apellidos, puesto, sueldo, edad, num_hijos 
y sucursal e inicializarlas con los siguientes valores:*/

if (isset($_POST['enviar'])) {
    // Creamos las variables
    $codigo = $_POST['codigo'];
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $puesto = $_POST['puesto'];
    $sueldo = $_POST['sueldo'];
    $edad = $_POST['edad'];
    $num_hijos = $_POST['num_hijos'];
    $sucursal = $_POST['sucursal'];

    // Creamos el array 
    $empleado = array(
        $codigo,
        $nombre,
        $apellidos,
        $puesto,
        $sueldo,
        $edad,
        $num_hijos,
        $sucursal
    );

    /* Generar la tabla HTML horizontal */
    echo "<table border='1' cellpadding='10'>";
 
    /* Fila de cabeceras */
    echo "<tr>";
    echo "<th>codigo</th>";
    echo "<th>nombre</th>";
    echo "<th>apellidos</th>";
    echo "<th>puesto</th>";
    echo "<th>sueldo</th>";
    echo "<th>edad</th>";
    echo "<th>num_hijos</th>";
    echo "<th>sucursal</th>";
    echo "</tr>";
 
    /* Fila de valores */
    echo "<tr>";
    foreach($empleado as $valor){
        echo "<td>$valor</td>";
    }
    echo "</tr>";
 
    echo "</table>";
    
    echo "<br>";
} else {
    header("Location: ejercicio11.html");
    exit;
}
