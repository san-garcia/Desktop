<?php
    // Nos conectamos a la base de datos 
    $pdo = new PDO('mysql:host=localhost;dbname=videoclub','root','');
    
    echo "Conexión establecida con éxito"."<br>";

    // Creamos la sentencia 
    $sentencia = $pdo->query("select * from peliculas");

    // Ejecutamos la sentencia 
    $sentencia->execute(); // Tendremos que recuperar todos los registros de peliculas

    // Recuperamos los registros en un Array multidimensional
    $registros = $sentencia->fetchAll(PDO::FETCH_ASSOC);

    // Obtenemos el numero de registros 
    $numRegistros = $sentencia -> rowCount();
    echo "Número de registros $numRegistros";
?>