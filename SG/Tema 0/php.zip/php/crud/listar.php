<?php
    // EJERCICIO TIPO EXAMEN
    // Nos conectamos a la base de datos 
    // Tiene tres parametros, el primero el host y nombre de la bbdd, usuario y contraseña
    $pdo = new PDO('mysql:host=localhost;dbname=videoclub','root','');
    
    echo "Conexión establecida con éxito"."<br>";

    // Creamos la sentencia 
    $sentencia = $pdo->query("select * from peliculas");

    // Ejecutamos la sentencia 
    $sentencia->execute(); // Tendremos que recuperar todos los registros de peliculas

    // Recuperamos los registros en un Array multidimensional
    $registros = $sentencia->fetchAll(PDO::FETCH_ASSOC); // Para hacerlo asociativa hariamos en el () PDO::FETCH_ASSOC
 
    // Volcamos los datos en bruto
    //var_dump($registros); // Esto se muestra como un array asociativo y aun array normal

    // Mostramos los datos de la pelicula de la posicion 2
    //$posicion = 2;
    for($posicion = 0; $posicion<count($registros);$posicion++) {
        echo "Código: ".$registros[$posicion]['codpelicula']."<br>";
        echo "Titulo: ".$registros[$posicion]['titulo']."<br>";
        echo "Tema: ".$registros[$posicion]['tema']."<br>";
        echo "Duración: ".$registros[$posicion]['duracion']."<br>";
        echo "Precio: ".$registros[$posicion]['precio']."<br>";
        echo "<hr>";
    }
?>