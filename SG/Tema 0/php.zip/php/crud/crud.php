<?php
    // Nos conectamos a la base de datos 
    $pdo = new PDO('mysql:host=localhost;dbname=videoclub', 'root', '');

    echo "Conexión establecida con éxito" . "<br>";

    
?>