package actividad8tema0;

public class Mueble {

    /*Actividad 8. Crear una aplicación con una clase llamada mueble. Las propiedades o atributos de la clase mueble serán el código del mueble, 
    material y el precio. Los métodos de la clase Inmueble serán el método constructor por defecto, el constructor que inicializa los valores de los 
    atributos, los métodos set y get y el método toString. 
    Además un método sobrecargado llamado calculaIVA. Si no recibe parámetro, calcula el 21% sobre el precio. 
    Y si recibe como parámetro un porcentaje de IVA y devuelve el importe del IVA aplicando dicho porcentaje.*/
    
    // Declaramos los atributos 
    private int codMueble;
    private String material;
    private double precio;
    
    // Constructor 
    public Mueble(int codMueble, String material, double precio) {
        this.codMueble = codMueble;
        this.material = material;
        this.precio = precio;
    }
    
    // Getters y setters 
    public int getCodMueble() {
        return codMueble;
    }

    public void setCodMueble(int codMueble) {
        this.codMueble = codMueble;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    // Método toString  

    @Override
    public String toString() {
        return "Mueble " + "código mueble: " + codMueble + " material: " + material + " precio: " + precio;
    }
    
    // Método sobrecargado
    public double calculaIVA() {
        precio+=precio*0.21;
        return precio;
    }
    
    // Realizamos este método por si el iva no llega a ser 21 y podría ser otro porcentaje 
    public double calculaIVA(double iva) {
        precio+=precio*(iva/100);
        return precio;
    }
}
