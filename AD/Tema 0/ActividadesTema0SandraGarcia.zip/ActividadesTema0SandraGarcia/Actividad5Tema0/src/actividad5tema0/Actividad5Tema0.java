package actividad5tema0;

import java.util.Scanner;

public class Actividad5Tema0 {
    
    /*Actividad 5. Introducir por teclado el importe de facturas hasta introducir el valor 0 y mostrar el menor importe de las facturas. 
    Realizar el ejercicio con un bucle do-while. Mostrar los datos finales del modo: 
    El menor importe de las facturas introducido es {importeMenor}*/
    public static void main(String[] args) {
        // Introducimos el teclado 
        Scanner teclado = new Scanner (System.in);
        
        // Declaramos las variables 
        int importeMenor = Integer.MAX_VALUE, factura;
        
        // Función do-while 
        do {            
            System.out.println("Introduce el importe de la factura:");
            factura = teclado.nextInt();
            // Realizamos la función if en el caso de que tengamos un numero menor
            if (factura < importeMenor && factura !=0) {
                importeMenor = factura;
            }
        } while (factura!=0);
        System.out.println("El menor importe de las facturas introducido es "+importeMenor);
    }
    
}
