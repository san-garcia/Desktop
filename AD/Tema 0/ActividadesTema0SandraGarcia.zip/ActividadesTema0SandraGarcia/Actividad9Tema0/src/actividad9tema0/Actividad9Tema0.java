package actividad9tema0;

public class Actividad9Tema0 {

    public static void main(String[] args) {
        // Instancia de la clase Mueble
        Mueble m1 = new Mueble(1, "madera", 100);
        
        // Instancia de la clase Mesa
        Mesa me1 = new Mesa(2, "plastico", 200, 20, 50);
        
        // Instancia de la clase Silla 
        Silla si1 = new Silla(3, "madera", 50, 4, "madera", true);
        
        // Mostramos los datos
        System.out.println(m1.toString());
        System.out.println(me1.toString());
        System.out.println(si1.toString());
        
        // Calculamos el precio de los productos
        System.out.println("El precio final del mueble es "+m1.calculaIVA());
        System.out.println("El precio final del mesa es "+me1.calculaIVA());
        System.out.println("El precio final del silla es "+si1.calculaIVA());
       
    }
    
}
