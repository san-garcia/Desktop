package actividad9tema0;

    /*Actividad 9. Crear dos subclases de la clase mueble de la actividad anterior llamadas Mesa y Silla. 

    La subclase Mesa hereda de la clase mueble atributos y métodos. Además dispone de atributos con el ancho, largo de la mesa. 
    Además se redefine el método constructor que permite inicializa todos sus atributos y el método toString() que muestra los atributos todos 
    los atributos de la subclase. 
    
    La subclase Silla hereda de la clase mueble atributos y métodos. Además dispone de atributos con el numPatas, materialTapizado y respaldo (boolean). 
    Además se redefine el método constructor que permite inicializa todos sus atributos y el método toString() que muestra los atributos todos los 
    atributos de la subclase. 

    Crear varias instancias de ambas subclases, mostrar sus datos, calcular su precio final para todas las instancias.*/

public class Silla extends Mueble {
    
    // Atributos de Silla 
    private int numPatas;
    private String materialTapizado;
    private boolean respaldo;
    
    public Silla(int codMueble, String material, double precio, int numPatas, String materialTapizado, boolean respaldo) {
        super(codMueble, material, precio);
        this.numPatas = numPatas;
        this.materialTapizado = materialTapizado;
        this.respaldo = respaldo;
    }

    // Getters y setters
    public int getNumPatas() {
        return numPatas;
    }

    public void setNumPatas(int numPatas) {
        this.numPatas = numPatas;
    }

    public String getMaterialTapizado() {
        return materialTapizado;
    }

    public void setMaterialTapizado(String materialTapizado) {
        this.materialTapizado = materialTapizado;
    }

    public boolean isRespaldo() {
        return respaldo;
    }

    public void setRespaldo(boolean respaldo) {
        this.respaldo = respaldo;
    }
    
    
    // Método toString
    @Override
    public String toString() {
        return "Silla " + " número de patas: " + numPatas + " material tapizado: " + materialTapizado + " respaldo: " + respaldo;
    }
    
}
