package actividad9tema0;

    /*Actividad 9. Crear dos subclases de la clase mueble de la actividad anterior llamadas Mesa y Silla. 

    La subclase Mesa hereda de la clase mueble atributos y métodos. Además dispone de atributos con el ancho, largo de la mesa. 
    Además se redefine el método constructor que permite inicializa todos sus atributos y el método toString() que muestra los atributos todos 
    los atributos de la subclase. 
    
    La subclase Silla hereda de la clase mueble atributos y métodos. Además dispone de atributos con el numPatas, materialTapizado y respaldo (boolean). 
    Además se redefine el método constructor que permite inicializa todos sus atributos y el método toString() que muestra los atributos todos los 
    atributos de la subclase. Crear varias instancias de ambas subclases, mostrar sus datos, calcular su precio final para 
    todas las instancias.*/

public class Mesa extends Mueble {
    // Atribuos de la clase Mesa 
    private int ancho, largo;
    
    public Mesa(int codMueble, String material, double precio, int ancho, int largo) {
        super(codMueble, material, precio);
        this.ancho = ancho;
        this.largo = largo;
    }
    
    // Getters y setters
    public int getAncho() {
        return ancho;
    }    

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }

    public int getLargo() {
        return largo;
    }

    
    public void setLargo(int largo) {
        this.largo = largo;
    }

    // Método toString
    @Override
    public String toString() {
        return "Mesa " + " ancho: " + ancho + " largo: " + largo;
    }
}
