package actividad9tema0;

public class Mueble {

    /*Actividad 9. Crear dos subclases de la clase mueble de la actividad anterior llamadas Mesa y Silla. 
    
    La subclase Mesa hereda de la clase mueble atributos y métodos. Además dispone de atributos con el ancho, largo de la mesa. 
    Además se redefine el método constructor que permite inicializa todos sus atributos y el método toString() que muestra los atributos todos 
    los atributos de la subclase. 
    
    La subclase Silla hereda de la clase mueble atributos y métodos. Además dispone de atributos con el numPatas, materialTapizado y respaldo (boolean). 
    Además se redefine el método constructor que permite inicializa todos sus atributos y el método toString() que muestra los atributos todos los 
    atributos de la subclase. Crear varias instancias de ambas subclases, mostrar sus datos, calcular su precio final para 
    todas las instancias.*/
    
    // Declaramos los atributos 
    private int codMueble;
    private String material;
    private double precio;

    // Constructor 
    public Mueble(int codMueble, String material, double precio) {
        this.codMueble = codMueble;
        this.material = material;
        this.precio = precio;
    }

    // Getters y setters 
    public int getCodMueble() {
        return codMueble;
    }

    public void setCodMueble(int codMueble) {
        this.codMueble = codMueble;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    // Método toString  
    @Override
    public String toString() {
        return "Mueble " + "código mueble: " + codMueble + " material: " + material + " precio: " + precio;
    }

    // Método sobrecargado
    public double calculaIVA() {
        precio += precio * 0.21;
        return precio;
    }

    // Realizamos este método por si el iva no llega a ser 21 y podría ser otro porcentaje 
    public double calculaIVA(double iva) {
        precio += precio * (iva / 100);
        return precio;
    }
}
