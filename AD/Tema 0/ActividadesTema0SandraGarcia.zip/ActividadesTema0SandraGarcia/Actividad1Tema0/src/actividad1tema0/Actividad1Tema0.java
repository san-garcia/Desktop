package actividad1tema0;

import java.util.Scanner;

public class Actividad1Tema0 {

    /*Actividad 1. Pedir por teclado el Nombre, Sueldo, Categoría Laboral (1, 2, 3 o 4) y Población 
    de un empleado. 
    Si el empleado es de Valencia aumentar el sueldo un 20%  y mostrar los datos finales del modo: 
    El empleado {nombre} con categoría laboral {cLaboral} de {población} cobra {sueldoFinal} */
	
    public static void main(String[] args) {
        // Introducimos el teclado 
        Scanner teclado = new Scanner (System.in);
        
        // Nombramos las variables
        String nombre, poblacion;
        int cLaboral;
        double sueldoFinal;
        
        // Pedimos los datos 
        System.out.println("Introduce el nombre:");
        nombre = teclado.next();
        
        System.out.println("Introduce su sueldo:");
        sueldoFinal = teclado.nextDouble();
        
        System.out.println("Introduce su categoría laboral:");
        cLaboral = teclado.nextInt();
        
        System.out.println("Introduzca la población:");
        poblacion = teclado.next();
        
        // Colocamos el if para comprobar si el empleado es de Valencia 
        if (poblacion.equals("Valencia")) {
            sueldoFinal*=1.20;
        }
        
        // Mostramos el mensaje por consola 
        System.out.println("El empleado "+nombre+" con categoría laboral "+cLaboral+" de "+poblacion+" cobra "+sueldoFinal);
    }

}
