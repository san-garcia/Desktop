package actividad6tema0;

import java.util.Scanner;

public class Actividad6Tema0 {
    /*Actividad 6. Introducir por teclado el importe de facturas hasta introducir el valor 0 y mostrar 
    el mayor importe de las facturas. Realizar el ejercicio con un bucle while. 
    Mostrar los datos finales del modo: 
    El mayor importe de las facturas introducido es {importeMayor}*/
    public static void main(String[] args) {
        // Introducimos por teclado 
        Scanner teclado = new Scanner (System.in);
        
        // Declaramos las variables 
        int importeMayor = 0, factura = 1;// Tenemos que ponerle otro valor a la variable, ya que si ponemos 0 supone que esto se termina
        
        // Escribimos la función while 
        while (factura!=0) {            
            System.out.println("Introduce el importe de la factura:");
            factura = teclado.nextInt();
            // Creamos la condicion if, en el caso de que la factura sea mayor que el importe
            if (factura > importeMayor) {
                importeMayor = factura;
                
            }
            
        }
        System.out.println("El mayor importe de las facturas introducido es "+importeMayor);
    }
    
}
