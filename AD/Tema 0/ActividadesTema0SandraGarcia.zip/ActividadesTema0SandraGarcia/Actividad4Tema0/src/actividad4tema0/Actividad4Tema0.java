package actividad4tema0;

import java.util.Scanner;

public class Actividad4Tema0 {

    /*Actividad 4. Introducir por teclado el importe de 10 facturas y calcular el importe total de las facturas. Mostrar los datos finales del modo: 
    El total del las facturas es {importeFinal} */
    public static void main(String[] args) {
        // Introducimos el teclado 
        Scanner teclado = new Scanner (System.in);
        
        // Nombramos las variables 
        int factura, importeFinal = 0;
        
        // Creamos un for hasta que lleguemos a las 1o facturas que necesitamos
        for (int i = 0; i < 10; i++) {
            // Pedimos el número de factura 
            System.out.println("Introduce el importe de la factura:");
            factura = teclado.nextInt();
            importeFinal = factura+importeFinal;
        }
        System.out.println("El total del las facturas es "+importeFinal);
    }

}
