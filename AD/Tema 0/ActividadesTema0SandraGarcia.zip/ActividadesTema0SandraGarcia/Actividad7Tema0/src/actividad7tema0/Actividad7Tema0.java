package actividad7tema0;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Actividad7Tema0 {
    /*Actividad 7. Pedir por teclado dos fechas e indicar el día de la semana de cada fecha y los días transcurridos entre ambas fechas. 
    Mostrar los datos finales del modo: 
    Día de la Semana de la Fecha Inicial: {diaSemanaInicial} 
    Día de la Semana de la Fecha Final: {diaSemanaIFinal} 
    Días transcurridos entre {fechaIncial} y {fechaFinal}: {diasTranscurridos} */
    public static void main(String[] args) {
        // Introducimos el teclado 
        Scanner teclado = new Scanner(System.in);
        
        // Declaramos las variables de fechas 
        LocalDate fechaIncial, fechaFinal;
        // Para poder pedir las fechas debemos de tener variables de tipo String
        String f1, f2;
        String diaSemanaInicial, diaSemanaFinal;
        
        // Pedimos mediante la consola
        System.out.println("Introduce la fecha inicial:");
        f1 = teclado.next();
        System.out.println("Introduce la fecha final:");
        f2 = teclado.next();
        
        // Declramos la varibale formato con DateTimeFormatter
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");// Con ofPattern declaramos como queremos que salga por consola la fecha
        
        // Pasamos las fechas inicial y final con LocalDate.parse, dentro de el colocaremos las fechas tipo string y la variable formato 
        fechaIncial = LocalDate.parse(f1, formato);
        fechaFinal = LocalDate.parse(f2, formato);
        diaSemanaInicial = fechaIncial.getDayOfWeek().toString();// Pasamos a String para mostrar el dia de la semana
        diaSemanaFinal = fechaIncial.getDayOfWeek().toString();
        
        // Declaramos una variable diasTranscurridos, para saber el timepo que se transcurre entre ambas fechas
        long diasTranscurridos = ChronoUnit.DAYS.between(fechaIncial, fechaFinal);
        
        // Mostramos mediante consola
        System.out.println("Día de la Semana de la Fecha Inicial:"+fechaIncial);
        System.out.println("Día de la Semana de la Fecha Final:"+fechaFinal);
        System.out.println("Días transcurridos entre "+fechaIncial+" y "+fechaFinal+": "+diasTranscurridos);
    }
    
}
