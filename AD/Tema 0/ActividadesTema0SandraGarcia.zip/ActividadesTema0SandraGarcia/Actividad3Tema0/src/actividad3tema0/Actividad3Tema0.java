package actividad3tema0;

import java.util.Scanner;

public class Actividad3Tema0 {

    /*Actividad 3 . Pedir por teclado el Nombre, Sueldo, Categoría Laboral (1, 2, 3 o 4) y Población de un empleado. 
    Si la Categoría Laboral del empleado es 1 aumentar el sueldo un 10%, si la Categoría Laboral del empleado es 2 aumentar el sueldo un 20%, 
    si la Categoría Laboral del empleado  es 3 aumentar el sueldo un 30%, si la Categoría Laboral del empleado es 4 aumentar el sueldo un 40% 
    y en cualquier otro caso el sueldo no se modifica. 
    Mostrar los datos finales del modo: El empleado {nombre} con categoría laboral {cLaboral} de {población} cobra {sueldoFinal}*/
    public static void main(String[] args) {
        // Introducimos el teclado
        Scanner teclado = new Scanner(System.in);

        // Nombramos las variables
        String nombre, poblacion;
        int cLaboral;
        double sueldoFinal;

        // Pedimos los datos
        System.out.println("Introduce el nombre:");
        nombre = teclado.next();

        System.out.println("Introduce su sueldo:");
        sueldoFinal = teclado.nextDouble();

        System.out.println("Introduce su categoría laboral:");
        cLaboral = teclado.nextInt();

        System.out.println("Introduzca la población:");
        poblacion = teclado.next();
        // Introducimos un if para comprobar si es de las siguientes categorias
        if (true) {
            // Creamos un switch
            switch (cLaboral) {
                case 1:
                    sueldoFinal *= 1.10;
                    break;
                case 2:
                    sueldoFinal *= 1.20;
                    break;
                case 3:
                    sueldoFinal *= 1.30;
                    break;
                case 4:
                    sueldoFinal *= 1.40;
                    break;
                default:
                    System.out.println("Ese número no corresponde con ninguna catgoría laboral");
                    break;
            }
        }
        System.out.println(" El empleado "+nombre+" con categoría laboral "+cLaboral+" de "+poblacion+" cobra "+sueldoFinal);
    }
}
