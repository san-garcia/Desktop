package actividad10tema0;

import java.util.ArrayList;

public class Actividad10Tema0 {

    /*Actividad 10. Crear una aplicación que permita gestionar la cola de matriculas de estudiantes en una Universidad:
    Crear una clase llamada Alumno que tenga los atributos dni, nombre, apellidos y curso. 
    Crear constructor que inicialice todos los atributos de la clase, métodos setter, getter y toString(). 
    Crear un ArrayList para almacenar los alumnos.
    Realizar las siguientes acciones:
        Introducir alumnos y almacenarlos en el ArrayList. 
        Listar todos los alumnos que hay en la cola. 
        Eliminar un alumno atendido de la cola (el primero). 
        Volver a listar todos los alumnos que hay en la cola.*/
    
    public static void main(String[] args) {
        // Creamos el ArrayList 
        ArrayList<Alumno> listaAlumnos = new ArrayList<>();
        
        // Almacenamos a los alumnos 
        listaAlumnos.add(new Alumno("12345678D", "Luis", "Garcia", 1));
        listaAlumnos.add(new Alumno("12345679A", "Alejandra", "Fernandez", 4));
        listaAlumnos.add(new Alumno("12345673B", "Pablo", "Asesensio", 3));
        listaAlumnos.add(new Alumno("12345671C", "Carla", "Muro", 2));
        
        // Listamos los alumnos que tenemos 
        for (Alumno a : listaAlumnos){
            System.out.println(a);
        }
        
        // Eliminamos el primer alumno de la lista 
        listaAlumnos.remove(0);
        
        System.out.println("*****************************************************");
        // Listamos los alumnos que tenemos 
        for (Alumno a : listaAlumnos){
            System.out.println(a);
        }
    }
    
}
