package actividad10tema0;

    /*Actividad 10. Crear una aplicación que permita gestionar la cola de matriculas de estudiantes en una Universidad:
    Crear una clase llamada Alumno que tenga los atributos dni, nombre, apellidos y curso. 
    Crear constructor que inicialice todos los atributos de la clase, métodos setter, getter y toString(). 
    Crear un ArrayList para almacenar los alumnos.
    Realizar las siguientes acciones:
    Introducir alumnos y almacenarlos en el ArrayList. 
    Listar todos los alumnos que hay en la cola. 
    Eliminar un alumno atendido de la cola (el primero). 
    Volver a listar todos los alumnos que hay en la cola.*/
public class Alumno {
    // Atributos 
    private String dni, nombre, apellidos;
    private int curso;
    
    // Constructor 
    public Alumno(String dni, String nombre, String apellidos, int curso) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.curso = curso;
    }
    
    // Getters y setters 
    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getCurso() {
        return curso;
    }

    public void setCurso(int curso) {
        this.curso = curso;
    }
    
    // Método toString 

    @Override
    public String toString() {
        return "Alumno " + " DNI: " + dni + " nombre: " + nombre + " apellidos: " + apellidos + " curso: " + curso;
    }
    
}
